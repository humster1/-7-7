fun main() {
    println("Сколько градусов в фаренгейтах?")
    try {
        var X: Int = readLine()!!.toInt()

        var Y: Int = 0
        Y= 5/9 * (X - 32)
        println("Ваш ответ: $Y")
    } catch (e:Exception) {
        println("Ошибка")
    }

}