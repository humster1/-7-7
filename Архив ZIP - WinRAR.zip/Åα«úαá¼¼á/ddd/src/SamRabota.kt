import kotlin.math.pow
import kotlin.math.sin

fun main() {
    println("Значение X")
    val S: String? = readLine()
    var X: Double = S!!.toDouble()
    if(X > 1.1) {
        X =  9 - X
        println("F(x):  $X")
    } else {
        val result = X.pow(4.0)
        X  = (sin(3 * X) / (result + 1))
        println("F(x): $X")
    }
}