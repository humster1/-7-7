import kotlin.random.Random

fun main() {
    while(true){
        val X =  (1..10).random()
        println("Угадывай число")
        val s: String? = readLine()
        val Y: Int = s!!.toInt()
        when(X == Y){
            true -> println("Вы угадали")
            false -> if(X < Y) {
                println("Перебор")
            } else println("Недобор")
        }
    }

}
