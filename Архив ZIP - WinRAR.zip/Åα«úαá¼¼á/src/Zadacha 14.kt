import kotlin.math.sqrt

fun main() {
    try {
        println("Введи стороны треугольника:")
        println("A:")
        var A: Double = readLine()!!.toDouble()
        println("B:")
        var B: Double = readLine()!!.toDouble()
        println("C:")
        var C: Double = readLine()!!.toDouble()
        var P: Double = 0.0
        var S: Double = 0.0
        P = (A+B+C) / 2
        S = sqrt(P*(P-A)*(P-B)*(P-C))
        println("Ответ: $S")
    } catch (e:Exception) {
        println("Ошибка")
    }

}