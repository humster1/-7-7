fun main() {
    try {
        println("Введи 2 координаты")
        println("Первая координата")
        var X: Int = readLine()!!.toInt()
        println("Вторая координата")
        var Y: Int = readLine()!!.toInt()
        when {
            (X>0)&&(Y>0) -> println("Первая четверть");
            (X>0)&&(Y<0) -> println("Четвертая четверть");
            (X<0)&&(Y>0) -> println("Вторая четверть");
            (X<0)&&(Y<0) -> println("Третья четверть");
        }
    } catch (e:Exception) {
        println("Ошибка")
    }

}



