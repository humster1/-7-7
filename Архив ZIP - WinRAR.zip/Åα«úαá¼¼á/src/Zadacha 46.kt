fun main() {
    try {
        println("Введи день недели")
        var X: String = readLine().toString()
        when {
            (X == "Понедельник") -> println("Работай")
            (X == "Вторник") -> println("Работай")
            (X == "Среда") -> println("Работай")
            (X == "Четверг") -> println("Работай")
            (X == "Пятница") -> println("Работай")
            (X == "Субббота") -> println("Отдыхай")
            (X == "Воскресенье") -> println("Отдыхай")
        }
    } catch (e:Exception) {
        println("Ошибка")
    }

}