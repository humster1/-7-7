fun main() {
   try {
      println("Задайте условие")
      println("Первое условие")
      var k: Double = readLine()!!.toDouble()
      println("Второе условие")
      var a: Double = readLine()!!.toDouble()
      println("Третье условие")
      var b: Double = readLine()!!.toDouble()
      println("Чему равен X")
      var X: Double = readLine()!!.toDouble()
      var y: Double = 0.0
      var y1: Double = 0.0
      y1 = a / X
      y = k * X + b
      y /= y1
      println("Ваш ответ: $y")
   } catch(e:Exception) {
      ("Ошибка")
   }

}