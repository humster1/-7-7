import kotlin.math.sqrt

fun main() {
    try{
     println("Введи значения:")
     println("x1:")
        var X1: Double = readLine()!!.toDouble()
        println("x2:")
        var X2: Double = readLine()!!.toDouble()
        println("x3:")
        var X3: Double = readLine()!!.toDouble()
        println("y:")
        var Y1: Double = readLine()!!.toDouble()
        println("y2:")
        var Y2: Double = readLine()!!.toDouble()
        println("y3:")
        var Y3: Double = readLine()!!.toDouble()

        var P: Double = 0.0
        var P1: Double = 0.0
        var L: Double = 0.0;
        var L1: Double = 0.0;

        P = ((X1 + X2 + X3)) / 2
        L = (P*(P-X1)*(P-X2)*(P-X3))
        P1 =  (Y1 + Y2 + Y3) / 2
        L1 = (P1*(P1-Y1)*(P1-Y2)*(P1-Y3))
        P /= 2
        P1 /= 2

        println("Площаль первого треугольника: $L")
        println("Периметр первого треугольника: $P")
        println("Площаль второго треугольника: $L1")
        println("Периметр второго треугольника: $P1")

    } catch (e:Exception) {
        println("Ошибка")
    }
}